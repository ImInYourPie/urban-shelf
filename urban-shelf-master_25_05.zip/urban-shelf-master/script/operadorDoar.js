window.onload = function(){
    //1. CRIAR REFERÊNCIAS AOS VARIOS ELEMENTOS
    let doarLivroTitulo = document.getElementById("doarLivroTitulo")
    let doarLivroCapa = document.getElementById("doarLivroCapa")
    let doarLivroDescription = document.getElementById("doarLivroDescription")
    let doarLivroAutores = document.getElementById("doarLivroAutores")
    let doarLivroDataLançamento = document.getElementById("doarLivroDataLançamento")
    let doarLivroGenero = document.getElementById("doarLivroGenero")
    let doarLivroTags = document.getElementById("doarLivroTags")
    let doarLivroEditora = document.getElementById("doarLivroEditora")
    let doarLivroPaginas = document.getElementById("doarLivroPaginas")
    let doarLivroEstado = document.getElementById("doarLivroEstado")
    let doarLivroDoador = document.getElementById("doarLivroDoador")
    let doarLivroDataDonation = document.getElementById("doarLivroDataDonation")
    let doarLivroBiblioteca = document.getElementById("doarLivroBiblioteca")
    
    let formDoarLivro = document.getElementById("formDoarLivro")
   
    //2. DEFINIR DATA MAXIMA  DE LANÇAMENTO E DOAÇÃO POSSIVEL 
    let dataAtual = new Date()
    let dd = dataAtual.getDate()
    let mm = dataAtual.getMonth()+1
    let yyyy= dataAtual.getFullYear()

    let new_dataAtual=""
    if(mm >=10 && dd>=10){  
        new_dataAtual = yyyy.toString()+"-"+mm.toString()+"-"+dd.toString()

    }
    else if(mm <10 && dd>=10){
        new_dataAtual = yyyy.toString()+"-0"+mm.toString()+"-"+dd.toString()

    }
    else if(mm <10 && dd<10){
        new_dataAtual = yyyy.toString()+"-0"+mm.toString()+"-0"+dd.toString()

    }

    doarLivroDataLançamento.setAttribute("max", new_dataAtual)
    doarLivroDataDonation.setAttribute("max", new_dataAtual)

    //3. ALIMENTAR OPÇOES DE GENERO
    for (var i = 0; i < arrayCategorias.length; i++) {
       
        doarLivroGenero.innerHTML += "<option value='"+arrayCategorias[i]._nameCategory+"'>"+arrayCategorias[i]._nameCategory+"</option>"
        
    }

    //4. ALIMENTAR OPÇOES DE TAGS
    for (var i = 0; i < arrayTags.length; i++) {
        doarLivroTags.innerHTML += "<option value='"+arrayTags[i]._nameTag+"'>"+arrayTags[i]._nameTag+"</option>"
        
    }

    //5. ALIMENTAR OPÇOES DE BIBLIOTECAS
    for (var i = 0; i < arrayBibliotecas.length; i++) {
        doarLivroBiblioteca.innerHTML += "<option value='"+arrayTags[i]._nameTag+"'>"+arrayTags[i]._nameTag+"</option>"
        
    } 


    //5. VERIFICAÇOES
    formDoarLivro.addEventListener("submit", function(event){

    })

    //6. CRIAR NOVO OBJETO "LIVRO" E ADICIONAR AO ARRAY
}