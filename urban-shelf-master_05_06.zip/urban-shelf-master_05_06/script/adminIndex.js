window.onload = function () {
    displayMapMarkes();
}